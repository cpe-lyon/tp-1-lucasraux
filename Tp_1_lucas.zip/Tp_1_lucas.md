﻿# Tp 1 – Bash prise en main

Manuel :

1. La commande which permet de trouver le ou les chemins d’un exécutable dans les différents répertoires listés dans la variable PATH
1. ` `Pour rechercher un terme dans un manuel on utilise la commande : **man which /option**
1. Pour quitter le manuel on utilise la touche **q**
1. La section 6 du manuel parle des jeux ainsi que les petits programs amusant disponibles sur le système avec la commande **man 6 intro**

Navigation dans l’arborescence des fichiers

1. Pour aller dans le dossier /var/log on utilise la commande **cd /var/log**
1. Pou remonter dans le dossier parents on utilise la commande **cd /var** ou **cd ..**
1. Pour retourner dans le dossier personnel on utilise la commande **cd**
1. Pour revenir au dossier précédent on utilise la commande **cd –**
1. On ne peut pas accéder au dossier root car nous n’avons pas les droits 
1. La commande est introuvable, car il faut au préalable s’accorder les droits avec la commande **sudo**, puis exécutez la commande **cd /root**
1. q
1. Il est possible de supprimer le Fichier1, grâce à la commande **rm Dossier1/Fichier1** mais il n’est pas possible de supprimer le Dossier1
1. C’est la commande **rmdir** qui permet de supprimer un dossier à la condition qu’il soit vide
1. Si on essaye la commande **rmdir** sur le Dossier2, on ne pourra pas le supprimer car il n’est pas vide
1. Pour supprimer le Dossier2 et son contenu on utilise la commande **rm –r**

Commandes importantes

1. Pour afficher l’heure on utilise la commande **date**, la commande **time** permet de lancer un programme avec des arguments et de définir le moment de l’arrêt du programme.
1. Ls permet d’afficher les fichiers dans un dossier alors que la permet d’afficher les dossiers cacher (commencent par un point).
1. Le programme ls se situe dans le dossier /user/bin/ls
1. Il n’y a pas d’entrer dans le manuel pour la commande ll. 
1. Pour afficher les fichiers dans le dossier /bin on utilise la commande ll 
1. La commande **ls ..** , permet de lister les fichiers du répertoires parents du dossier dans lequel on se trouve
1. C’est la commande **pwd** qui donne le chemin complet du dossier courant
1. La commande **echo ‘bip’ > plop** permet de** créer un fichier plop, ainsi que d’écrire le mot ‘bip’ dans le fichier. L’lorsque l’on exécute deux fois la commande, elle supprime le contenue du fichier 
1. La commande **echo ‘bip’ >> plop** permet d’ajouter le mot ‘bip’ au fichier 
1. La commande **sleep 10 | echo 'toto'** met en pause le shell pendant 10 secondes en affichant toto
1. La commande file permet de déterminer le type d’un fichier
1. L’lorsque l’on ajoute du contenu dans le fichier original après un lien\_sym le contenue est également ajouter dans le fichier lié. Si on supprime l’original, le fichier liée reste intact.
1. Lorsque l’on modifie lien\_phy, lien\_sym est également modifier, et inversement. D’autre part lorsque lien\_phy est supprimer lien\_sym deviens rouge et impossible à ouvrir.
1. Les raccourcis ctrl + S permet d’interrompre le défilement et ctrl + q permet de le reprendre 
1. La commande **head 5 /var/log/syslog** permet d’afficher les 5 premières lignes du fichier

La commande **tail -n 15 /var/log/syslog** permet d’afficher les 15 dernières ligne du fichier

La commande **tail –n 20** **/var/log/syslog | head 10** permet d’afficher les lignes 10 à 20

1. La commande **dmesg | less** affiche un caractère en continue 
1. Ce fichier contient les utilisateurs du système et leurs informations, le manuelle est accessible depuis man /etc/passwd

1. ` `La commande qui nous permet de savoir combien d’utilisateurs on un compte sur cette machine est : **wc –l /etc/passwd**
1. La commande **man -k conversion | wc -l** nous permet de voir que 141 pages de manuel comportent le mot-clé conversion dans leur description.
1. **La commande find / -iname "passwd"** nous permet de trouver les fichiers se nommant passwd
1. Afin d'enregistré les fichiers trouvés dans un fichier précis il faut faire **find / -iname "passwd" >> list\_passwd\_files.txt**. Pour rediriger les erreurs on utilise la commande **find / -iname "passwd" >> /dev/null** 
1. **Q**
1. Le fichier **history.log** se trouve dans /var/log/apt/history.log

Exercice 3 : Découverte de l’éditeur de texte nano

![Une image contenant texte

Description générée automatiquement](Aspose.Words.3a4e0281-cc19-4b52-a8b4-353c4fdb63e8.001.png)








` `![Une image contenant texte

Description générée automatiquement](Aspose.Words.3a4e0281-cc19-4b52-a8b4-353c4fdb63e8.002.png)

1. Pour d’déplacer les 10 première ligne il faut faire ctrl+K pour cut les 10 première ligne, par la suite avec ctrl+ flèche du bas on colle les lignes à la fin du fichier.

Pour annuler on utilise Alt+U ou sortir sans sauvegarder

![Une image contenant texte

Description générée automatiquement](Aspose.Words.3a4e0281-cc19-4b52-a8b4-353c4fdb63e8.003.png)

Exercice 4 : Personnalisation du shell

1. On créer une copie du fichier **.bashrc** avec la commande **cp .bashrc .bashrc\_bak**
1. ![Une image contenant texte

Description générée automatiquement](Aspose.Words.3a4e0281-cc19-4b52-a8b4-353c4fdb63e8.004.png)
1. ![Une image contenant texte, horloge, temps

Description générée automatiquement](Aspose.Words.3a4e0281-cc19-4b52-a8b4-353c4fdb63e8.005.png)


